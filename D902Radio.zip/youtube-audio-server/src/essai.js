var path = require('path');
var fs   = require('fs');
var ytdl = require('ytdl-core');

var url = 'https://www.youtube.com/watch?v=piW_ZPj5380';
var output = path.resolve(__dirname, 'video.mp4');

var video = ytdl(url, { begin: '165000' });
video.pipe(fs.createWriteStream(output));