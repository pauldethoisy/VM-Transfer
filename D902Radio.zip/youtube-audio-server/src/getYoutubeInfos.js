var fs = require('fs');
const { getInfo } = require('ytdl-getinfo')

var options = ['--username=radiod902@gmail.com', '--password=tontonD902'];

var jsonPlaylist = [];
var playlistList = [{"playlistName" : "Variété", "playlistId" : "PLxMrMiXu0IZFuwZpuAMa51POGDE9fRZgP"},{"playlistName" : "Chill", "playlistId" : "PLxMrMiXu0IZHKNtXaqP4L_GyzCcbUWjC0"},{"playlistName" : "Chill-Funk-Groovy", "playlistId" : "PLxMrMiXu0IZHXS0_ykq-Szfpvgx_rvcda"},{"playlistName" : "Disco", "playlistId" : "PLxMrMiXu0IZFqJOX7RJBr6ZeqFu0oCOAd"},{"playlistName" : "DeepHouse", "playlistId" : "PLxMrMiXu0IZHJRyVx7tkHb5TE-O0nsTsx"},{"playlistName" : "Funky-Groovy", "playlistId" : "PLxMrMiXu0IZH4TkVsCwNzPYkt4mL-XIxB"},{"playlistName" : "House-Disco", "playlistId" : "PLxMrMiXu0IZGcZ6GuxNqhsh4U7yW-FDLN"},{"playlistName" : "Deep-House-Electro-Minimal", "playlistId" : "PLxMrMiXu0IZHc8sNFTR83-iujcp4rIz6o"},{"playlistName" : "Techno-Hard-Deep", "playlistId" : "PLxMrMiXu0IZFM5GoA4lpbl2xHtqlVbLTx"}];

playlistList.forEach(function(playlistInfo) {

	getInfo(playlistInfo.playlistId, options, true).then(infos => {
		var json = [];

		console.log("Nouvelle playlist : " + playlistInfo.playlistName);
		console.log("Nombre de musiques : " + infos.items.length);

	    infos.items.forEach(function(info) {
			json.push({"name" : info.fulltitle, "duration" : info.duration, "urlId" : info.id});
		});

		if (json.length == infos.items.length) {
			jsonPlaylist.push({"playlistName" : playlistInfo.playlistName, "playlistInfo" : JSON.stringify(json)});

			if (jsonPlaylist.length == playlistList.length) {
				console.log("Playlists infos : " + JSON.stringify(jsonPlaylist));
				fs.writeFile('allPlaylistInfos.txt', JSON.stringify(jsonPlaylist), function(err) {
					if (err) throw err;
					console.log('All playlists informations had been saved!');
				});
			}
		}	
	});
});