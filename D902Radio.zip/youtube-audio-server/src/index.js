#!/usr/bin/env node
var fs = require('fs');
var reload = require('express-reload')
const socketIO = require('socket.io')
const http = require('http')
const path = require('path')
const express = require('express')
const nofavicon = require('express-no-favicons')
const youtube = require('./youtube')
const downloader = require('./downloader')

const app = express()
const server = http.createServer(app)
const io = socketIO.listen(server)

var showIncrement = 0;
var beginTime = 0;

var playlistInterval;
var newPlaylist = true;
var json;
var passPlaylist = 1;
var i = 0;
var time = new Date().getTime();
var dateMin = new Date().getMinutes();
var dateSec = new Date().getSeconds();
var playlistInfos = []; 
var minuteNow;
var hourNow;
/*fs.readFile('playlistInfos.txt', (err, data) => {
  if (err) throw err;
  var json = JSON.parse(data);
  while(json.length) {
      var selectedIndex = Math.floor(Math.random()*json.length);
      var selected = json.splice(selectedIndex, 1);
      playlistInfos.push(selected[0]);
  }
  //console.log("Nouvelle playlist : " + playlistName);
  console.log(Date());
  console.log(playlistInfos);
  //playlistInfos = randomPlaylist;
});

var i = 0;
var time = new Date().getTime();
var dateMin = new Date().getMinutes();
var dateSec = new Date().getSeconds();

startTimer();

function startTimer() {
  setInterval(timerUp,1000);
}

function timerUp() {
  var duration = playlistInfos[i].duration;

  console.log("Date actuelle : " + new Date().getTime());
  console.log("Date de fin   : " + (time + duration*1000));
  console.log("End Loop");

  if (new Date().getTime() >= time + (duration - 1)*1000) {
    console.log("Music Finished");
    time = new Date().getTime();
    i++;
    console.log(i);
  }
}*/






setInterval(function() {

  secondNow = new Date().getSeconds();
  minuteNow = new Date().getMinutes();
  hourNow = new Date().getHours();

  if (secondNow == 0 && minuteNow == 0 && (hourNow == 4 || hourNow == 5 || hourNow == 7 || hourNow == 9 || hourNow == 11 || hourNow == 14 || hourNow == 17 || hourNow == 20 || hourNow == 23)) {
    newPlaylist = true;
    //io.emit('ReSync', { message: "ReSync all clients", id: io.id });
    clearInterval(playlistInterval);
  }

  hourNow = new Date().getHours();

  if (hourNow >= 5 && hourNow < 7) {
    passPlaylist = 1;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 7 && hourNow < 9) {
    passPlaylist = 2;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 9 && hourNow < 11) {
    passPlaylist = 3;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 11 && hourNow < 14) {
    passPlaylist = 4;
    if(newPlaylist == true) {
      playlistInfos = [];
      newPlaylist = false;
      playPlaylist();
    }
  } else if (hourNow >= 14 && hourNow < 17) {
    passPlaylist = 5;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 17 && hourNow < 20) {
    passPlaylist = 6;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 20 && hourNow < 23) {
    passPlaylist = 7;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if ((hourNow >= 23 && hourNow < 24) || (hourNow >= 0 && hourNow < 4)) {
    passPlaylist = 8;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else if (hourNow >= 4 && hourNow < 5) {
    passPlaylist = 9;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = []; 
      playPlaylist();
    }
  } else {
    passPlaylist = 1;
    if(newPlaylist == true) {
      newPlaylist = false;
      playlistInfos = [];
      playPlaylist();
    }
  }

},1000);


function playPlaylist() {

  fs.readFile('allPlaylistInfos.txt', (err, data) => {
    if (err) throw err;
    json = JSON.parse(data)[passPlaylist-1];
    console.log("Nouvelle playlist : " + json.playlistName);
    var playlist = JSON.parse(json.playlistInfo);
    while(playlist.length) {
        var selectedIndex = Math.floor(Math.random()*playlist.length);
        var selected = playlist.splice(selectedIndex, 1);
        playlistInfos.push(selected[0]);
    }
    //console.log("Nouvelle playlist : " + playlistName);
    console.log(Date());
    console.log(playlistInfos.length);
    console.log(playlistInfos);
    //playlistInfos = randomPlaylist;
    i = 0;
    time = new Date().getTime();
    showIncrement = 0;

    playlistInterval = setInterval(function() {
      console.log(i);
      var duration = playlistInfos[i].duration;

      beginTime = beginTime + 1000;

      showIncrement = showIncrement + 1000;
      var showTime = time + showIncrement;
      console.log("Date actuelle : " + showTime);
      console.log("Date de fin   : " + (time + duration*1000));
      console.log("Begin time : " + beginTime);
      console.log("End Loop");

      if (new Date().getTime() >= time + (duration - 1)*1000) {
        console.log("Music Finished");
        beginTime = 0;
        if (minuteNow == 0 && (hourNow == 4 || hourNow == 5 || hourNow == 7 || hourNow == 9 || hourNow == 11 || hourNow == 14 || hourNow == 17 || hourNow == 20 || hourNow == 23)) {
          newPlaylist = true;
          //socket.emit('ReSync', { message: "ReSync all clients", id: socket.id });
          //clearInterval();
        } else {
          if (i < playlistInfos.length) {
            i++;
            //io.emit('ReSync', { message: "ReSync all clients", id: io.id });
          } else {
            i = 0;
          }
          io.emit('ReSync', { message: "ReSync all clients", id: io.id });
        }
        time = new Date().getTime();
        minuteNow = new Date().getMinutes();
        hourNow = new Date().getHours();
        console.log(i);
      }
    },1000);
  });
//}


/*function startTimer() {
  setInterval(timerUp,1000);
}*/

/*function timerUp() {*/
  /*console.log(i);
  var duration = playlistInfos[i].duration;

  console.log("Date actuelle : " + new Date().getTime());
  console.log("Date de fin   : " + (time + duration*1000));
  console.log("End Loop");

  if (new Date().getTime() >= time + (duration - 1)*1000) {
    console.log("Music Finished");
    time = new Date().getTime();
    minuteNow = new Date().getMinutes();
    hourNow = new Date().getHours();
    if (minuteNow == 0 && (hourNow == 4 || hourNow == 5 || hourNow == 7 || hourNow == 9 || hourNow == 11 || hourNow == 14 || hourNow == 17 || hourNow == 20 || hourNow == 23)) {
      newPlaylist = true;
      //clearInterval();
    } else {
      i++;
    }
    console.log(i);
  }*/
}







function listen (port, callback = () => {}) {
  app.use(nofavicon())

  app.get('/', (req, res) => {
    const file = path.resolve(__dirname, 'index.html')
    res.sendFile(file)

    /*var dateMin = new Date().getMinutes();
    if (dateMin == 33) {
      res.end('Reloading clients\n');
      io.sockets.emit('reload', {});
    }*/
  })

  app.get('/live', (req, res) => {
    const file = path.resolve(__dirname, 'index.html')
    res.sendFile(file)

    // Emit welcome message on connection
    io.on('connection', function(socket) {
        // Use socket to communicate with this particular client only, sending it it's own id
        socket.emit('newSong', { message: JSON.stringify(playlistInfos[i]), id: socket.id });
        //socket.emit('beginTime', {beginTime: beginTime});

        socket.on('i am client', console.log);

        console.log("This is client IP address : " + socket.request.connection.remoteAddress);
    });
  })

  app.get('/live/:videoId', (req, res) => {
    const videoId = req.params.videoId

    try {
      youtube.stream(videoId, {begin: beginTime}).pipe(res)
    } catch (e) {
      console.error(e)
      res.sendStatus(500, e)
    }
  })

  app.get('/search/:query/:page?', (req, res) => {
    const {query, page} = req.params
    youtube.search({query, page}, (err, data) => {
      if (err) {
        console.log(err)
        res.sendStatus(500, err)
        return
      }

      res.json(data)
    })
  })

  app.get('/get/:id', (req, res) => {
    const id = req.params.id

    youtube.get(id, (err, data) => {
      if (err) {
        console.log(err)
        res.sendStatus(500, err)
        return
      }

      res.json(data)
    })
  })

  app.use((req, res) => {
    res.sendStatus(404)
  })

  server.listen(port, callback)
}


module.exports = {
  listen,
  downloader,
  get: (id, callback) => youtube.get(id, callback),
  search: ({query, page}, callback) => youtube.search({query, page}, callback)
}
